package akathirk.cmu.edu.project4android;

import android.app.Activity;
import android.content.Context;
import android.graphics.Paint;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by Annamalai on 11/11/2017.
 * Source - https://github.com/quocnguyenvan/custom-listview-example/blob/master/app/src/main/java/com/example/quocnguyen/customlistviewexample/CustomListAdapter.java
 * Source - https://github.com/quocnguyenvan/media-player-demo/blob/master/app/src/main/java/com/quocnguyen/mediaplayerdemo/CustomMusicAdapter.java
 * The custom list adapter is used to set information to the list view that is displayed in the app
 */

public class CustomListAdapter extends ArrayAdapter<Songs> {

    ArrayList<Songs> songs;
    Context context;
    int resource;
    // media player to play the song URL in the app
    static private MediaPlayer mediaPlayer = new MediaPlayer();
    // flag used to play and stop the player song playes based on button clicked
    private Boolean flag = true;
    String url = "";

	/*
	 * The constructor method gets the array list of songs object to set info to the list view
	*/
    public CustomListAdapter(Context context, int resource, ArrayList<Songs> songs) {
        super(context, resource, songs);
        this.songs = songs;
        this.context = context;
        this.resource = resource;
        // release media player so that it stops when new search is made
        mediaPlayer.release();
        mediaPlayer = new MediaPlayer();
    }

    /*
     * View holder initialize the play and stop place holder in list view
    */
    private class ViewHolder {
        ImageView ivPlay, ivStop;
    }

    /*
     * getView is used to set each of the list view layout place holders with the info
     * received from the server and returns the view
    */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        // if view is null then create a new view holder and set the place holder of play and stop to
        // corresponding images
        if (convertView == null){
            viewHolder = new ViewHolder();
            LayoutInflater layoutInflater = (LayoutInflater) getContext()
                    .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.activity_custom_list_layout, null, true);
            viewHolder.ivPlay = (ImageView) convertView.findViewById(R.id.ivPlay);
            viewHolder.ivStop = (ImageView) convertView.findViewById(R.id.ivStop);
            convertView.setTag(viewHolder);
          // else get the views tag
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        // get the data in the specific position
        final Songs songs = getItem(position);
        // get the image view place holder and set it to the specific songs image
        ImageView imageView = (ImageView) convertView.findViewById(R.id.trackImageView);
        imageView.setImageBitmap(songs.getImage());
        // set song name
        TextView trackText = (TextView) convertView.findViewById(R.id.trackTextView);
        trackText.setText(songs.getName());
        // set artist view with artist name
        TextView artistText = (TextView) convertView.findViewById(R.id.artistTextView);
        artistText.setText(songs.getArtist());
        // set time view with track time
        TextView timeText = (TextView) convertView.findViewById(R.id.timeTextView);
        timeText.setText(songs.getTrackTime());
        // set genre
        TextView genreText = (TextView) convertView.findViewById(R.id.genreTextView);
        genreText.setText(songs.getGenre());
        // set release date
        TextView dateText = (TextView) convertView.findViewById(R.id.dateTextView);
        dateText.setText(songs.getReleaseDate());
        // set the discount price
        TextView discountText = (TextView) convertView.findViewById(R.id.discPriceTextView);
        discountText.setText(songs.getDiscountPrice());
        // set price
        TextView priceText = (TextView) convertView.findViewById(R.id.priceTextView);
        // if not free than do not strike through the price
        if (!songs.getPrice().equals("Free")) {
            priceText.setPaintFlags(priceText.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
          // else strike through the price
        } else {
            priceText.setPaintFlags(priceText.getPaintFlags()  & (~ Paint.STRIKE_THRU_TEXT_FLAG));
        }
        priceText.setText(songs.getPrice());
        // if play button is clicked
        viewHolder.ivPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // restart the media player
                mediaPlayer.reset();
                // get the audio URL
                url = songs.getaudioUrl();
                // set the audio stream type
                mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                // try to prepare for playback using async which returns immediately
                try {
                    mediaPlayer.setDataSource(url);
                    mediaPlayer.prepareAsync();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                // callback when the media source is ready
                mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    @Override
                    public void onPrepared(MediaPlayer mediaPlayer) {
                        // start the media player
                        mediaPlayer.start();
                        // flag set to false so that it could be stopped
                        flag = false;
                    }
                });
            }
        });

        // stop button clicked and flag is false
        viewHolder.ivStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!flag) {
                    // stop the media player
                    mediaPlayer.stop();
                }
            }
        });
        return convertView;
    }

}
