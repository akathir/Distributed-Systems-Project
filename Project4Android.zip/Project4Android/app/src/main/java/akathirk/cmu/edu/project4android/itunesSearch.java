package akathirk.cmu.edu.project4android;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

/**
 * Created by Annamalai on 11/11/2017.
 * Itunes search class which is called when button is clicked
 */

public class itunesSearch extends AppCompatActivity {
    // list view to store the information from API to the list in a specific format
    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*
         * R is the resource variable (static resources - in res directory). R will be the content view and its defined by activity main.
         * The click listener will need a reference to this object, so that upon successfully get information from  , it
         * can callback to this object with the information from API.  The "this" of the OnClick will be the OnClickListener, not
         * this itunesSearch.
         */
        lv = (ListView) findViewById(R.id.songsListView);
        final itunesSearch its = this;

        /*
         * Find the "submit" button, and add a listener to it
         */
        Button submitButton = (Button) findViewById(R.id.getJSONBtn);

        // Add a listener to the send button
        submitButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View viewParam) {
                // get the search name and send it to get info class
                String searchName = ((EditText)findViewById(R.id.nameEditText)).getText().toString();
                GetInfo gInfo = new GetInfo();
                gInfo.search(searchName,"song",its);
            }
        });
    }

    /*
     * This is called by the Getinfo object when the result is ready.  This allows for passing back the information for updating the text and list view
    */
    public void displayJsonString (ArrayList arrayList, int jsonLength, double timeDiff) {
        // get the
        TextView resultText = (TextView) findViewById(R.id.resultTextView);
        resultText.setText("About " + jsonLength + " results (" + timeDiff +" seconds)    " + "Play song preview");
        // use adapter to set the array list to layout
        CustomListAdapter adapter = new CustomListAdapter(
                getApplicationContext(), R.layout.activity_custom_list_layout, arrayList
        );
        lv.setAdapter(adapter);
    }

}
