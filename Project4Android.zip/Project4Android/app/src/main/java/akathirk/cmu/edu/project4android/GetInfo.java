package akathirk.cmu.edu.project4android;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Build;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

import javax.xml.transform.Source;

/**
 * Created by Annamalai on 11/11/2017.
 * This class provides capabilities to get info from server (search itunes API) given a search term.  The method "search" is the entry to the class.
 * Network operations cannot be done from the UI thread, therefore this class makes use of an AsyncTask inner class that will do the network
 * operations in a separate worker thread.  However, any UI updates should be done in the UI thread so avoid any synchronization problems.
 * onPostExecution runs in the UI thread, and it calls the displayJSONString method to do the update.
 */

public class GetInfo {

    itunesSearch its = null;

    ArrayList<Songs> arrayList;
    int jsonSize;
    long startTime = 0;
    long endTime = 0;

	/*
	 * search is the public Getinfo method.  Its arguments are the search term, and the itunesSearch object that called it.  This provides a callback
	 * path such that the displayJSONString method in that object is called when the info is available from the search.
	*/
    public void search(String searchName, String searchEntity, itunesSearch its) {
        // get the start time the time of request
        startTime = System.currentTimeMillis();
        this.its = its;
        new AsyncItunesSearch().execute(searchName + "," + searchEntity);

    }

    /*
     * AsyncTask provides a simple way to use a thread separate from the UI thread in which to do network operations.
     * doInBackground is run in the helper thread.
     * onPostExecute is run in the UI thread, allowing for safe UI updates.
     */
    private class AsyncItunesSearch extends AsyncTask<String,Void,ArrayList> {

        @Override
        protected ArrayList doInBackground(String... strings) {
            return search(strings[0]);
        }

        @Override
        protected void onPostExecute(ArrayList arrayList) {
            // get the end time the time of response
            endTime = System.currentTimeMillis();
            // find the time difference to display it in the app
            double timeDiff = Math.round((endTime-startTime)*0.001*100.00)/100.00;
            // send the array list, size of each request and time taken to get results to displayJsonString method
            its.displayJsonString(arrayList, jsonSize, timeDiff);
        }

        /*
         * Get info from server for the searchTerm argument, and return a array list that can be put in an list view
         */
        private ArrayList search (String input) {
            int status = 0;
            String jsonString = "";
            arrayList = new ArrayList<>();
            try {
                // depending upon which task you are running change the url variable
                String task1 = "https://shrouded-meadow-27857.herokuapp.com/";
                String task2 = "https://frozen-woodland-67953.herokuapp.com/";
                // right now the URL tries and connects to task2
                URL url = new URL(task2+"getResults" + "//" + input);
//                If you want to try it locally use the below URL (right now connects to Project4Task1)
//                URL url = new URL("http://10.0.2.2:8080/Project4Task1/getResults" + "//" + input);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // set the request method to GET to get info from the server
                conn.setRequestMethod("GET");
                // set the receiving type to be JSON
                conn.setRequestProperty("Content-Type", "application/json;charset=utf-8");
                // get the response code to see if the connection was successful or not
                status = conn.getResponseCode();
                if (status == 200) {
                    System.out.println("Connected to server.");
                    jsonString = getJSONString (conn);
                }
                // get the arraylist and send to the itunesSearch's displayJSONString method
                arrayList = getParsedList(jsonString);

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return arrayList;
        }

        /*
         * Given a URL referring to the server, connects with the server
         * and gets the JSON string that is returned by the server
        */
        private String getJSONString(HttpURLConnection conn) {
            String jsonString = "";
            String output;
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(
                        (conn.getInputStream())));
                // read the output and append it to the response
                while ((output = br.readLine()) != null) {
                    jsonString += output;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return jsonString;
        }

        /*
         * Given a json string it parses the string by converting it to JSON
         * Get the specific info the is required to be displayed by the app
        */
        private ArrayList getParsedList (String jsonString) {
            try {
                JSONObject object = new JSONObject(jsonString);
                // get the count of results
                jsonSize = object.getInt("resultCount");
                // get the array corresponding to results key JOSN array
                JSONArray jsonArray = object.getJSONArray("results");
                // Iterate through the array
                for (int i = 0, size = jsonArray.length(); i < size; i++) {
                    JSONObject JO = (JSONObject) jsonArray.get(i);
                    // for each of the JSON object get the info
                    Bitmap imageBitmap = getRemoteImage(new URL(JO.getString("artworkUrl100")));
                    String price = "";
                    String disctPrice = "";
                    // if the price is less than zero set the price variable to "Free"
                    // and discount to empty string
                    if (Double.parseDouble(JO.getString("trackPrice")) <= 0) {
                        price = "Free";
                        disctPrice = "";
                    } else {
                        price = JO.get("trackPrice") + " " + JO.get("currency");
                        disctPrice = JO.get("discountPrice") + " " + JO.get("currency");
                    }
                    String trkTime = "";
                    // If time is less than zero set it to 1 min
                    if (Double.parseDouble(JO.getString("trackTimeMillis")) <= 0) {
                        price = "1.00 min";
                    } else {
                        trkTime = JO.get("trackTimeMillis") + " min";
                    }
                    // add all the values to the song's method values to be used set the list view values
                    arrayList.add(new Songs(imageBitmap,JO.getString("trackName"),JO.getString("artistName"),trkTime,JO.getString("primaryGenreName"),JO.getString("releaseDate"),disctPrice,price,JO.getString("previewUrl")));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            return arrayList;
        }
        /*
         * Given a URL referring to an image, return a bitmap of that image
         * Connect to the specific image URL and get the bitmap stream
        */
        private Bitmap getRemoteImage(final URL url) {
            try {
                final URLConnection conn = url.openConnection();
                conn.connect();
                BufferedInputStream bis = new BufferedInputStream(conn.getInputStream());
                Bitmap bm = BitmapFactory.decodeStream(bis);
                bis.close();
                return bm;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

    }
}
