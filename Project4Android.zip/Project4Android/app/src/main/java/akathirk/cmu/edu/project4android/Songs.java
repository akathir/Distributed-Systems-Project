package akathirk.cmu.edu.project4android;

import android.graphics.Bitmap;

/**
 * Created by Annamalai on 11/11/2017.
 * Songs class to store all information of the songs method
 */

public class Songs {
    private Bitmap image;
    private String name;
    private String artist;
    private String trackTime;
    private String genre;
    private String releaseDate;
    private String discountPrice;
    private String price;
    private String audioUrl;

    // The constructor of songs class
    public Songs(Bitmap image, String name, String artist, String trackTime, String genre, String releaseDate, String discountPrice, String price, String audioUrl) {
        this.image = image;
        this.name = name;
        this.artist = artist;
        this.trackTime = trackTime;
        this.genre = genre;
        this.releaseDate = releaseDate;
        this.discountPrice = discountPrice;
        this.price = price;
        this.audioUrl = audioUrl;
    }

    // the setter and getter methods
    public Bitmap getImage() {
        return image;
    }

    public void setImage(Bitmap image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getTrackTime() {
        return trackTime;
    }

    public void setTrackTime(String trackTime) {
        this.trackTime = trackTime;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getDiscountPrice() {
        return discountPrice;
    }

    public void setDiscountPrice(String discountPrice) {
        this.discountPrice = discountPrice;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getaudioUrl() {
        return audioUrl;
    }

    public void setaudioUrl(String audioUrl) {
        this.audioUrl = audioUrl;
    }
}
