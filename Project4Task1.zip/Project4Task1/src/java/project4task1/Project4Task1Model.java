/*
 * @author Annamalai Kathirkamanathan
 * Project 4 - Task 1 (Model for the web application)
 * Last Modified: Nov 11, 2017
 * The model part of the web application helps in doing itunes search by requesting the Itunes API for the song, fetches the results
 * extracts only specific information that needs to be sent to the android application and sends back a JSON object back to sevlet.
 */
package project4task1;
// Import libraries
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Arrays;
import org.json.JSONArray;
import org.json.JSONObject;

public class Project4Task1Model {
    
    /**     
     * Arguments.
     * @param searchTerm The term you are searching for.
     * @param mediaType The type of content which is always song in this case
     * @return dataset a JSON object containing only the specific information required by the android application
     * @throws java.io.UnsupportedEncodingException
     * @throws java.io.FileNotFoundException
    */
    public JSONObject doItunesSearch(String searchTerm, String mediaType) 
            throws UnsupportedEncodingException, FileNotFoundException  {
        /*
         * URL encode searchTerm and mediaType, e.g. to encode spaces as %20
         *
         * There is no reason that UTF-8 would be unsupported.  It is the
         * standard encoding today.  So if it is not supported, we have
         * big problems, so don't catch the exception.
         */
        searchTerm = URLEncoder.encode(searchTerm, "UTF-8");
        mediaType = URLEncoder.encode(mediaType, "UTF-8");
        // store string returned from fetch
        String response = "";

        // Create a URL for the API to request infomation 
        String itunesURL =
                "https://itunes.apple.com/search?term="
                + searchTerm
                +"&entity=" + mediaType;
                
        // Fetch the JSON data
        response = fetch(itunesURL);
        
        // Parse the Json string to get the Json object
        JSONObject dataset = new JSONObject();
        // valueDouble to store time and price information     
        double valueDouble = 0;
        // valueString to store all other information
        String valueString = "";
        // Convert the string format of JSON to JSON object
        JSONObject object = new JSONObject(response); 
        // get the results key value as json array 
        JSONArray jsonArray = object.getJSONArray("results");
        // get the length of the array to store it in the dataset json to send it to app        
        int totalCount = jsonArray.length();                
        dataset.put("resultCount", totalCount);     
        // loop through the results json array to extract specific information to be sent to app
        for (int i = 0, size = jsonArray.length(); i < size; i++) {
            // create a temporary JSON object to add value to dataset JSON during each iteration
             JSONObject addValue = new JSONObject();
             // get the JSON object for each json array and store the names of the keys in elementNames
             JSONObject objectInArray = jsonArray.getJSONObject(i);
             String[] elementNames = JSONObject.getNames(objectInArray);
             // if any one of the element name is not in elementNames then add a default value to each of them
             // in their objectInArray so that there is no error because the specific element is not present
             if (!Arrays.asList(elementNames).contains("trackPrice")) {
                 objectInArray.put("trackPrice", 0);
             } 
             if (!Arrays.asList(elementNames).contains("artistName")) {
                 objectInArray.put("artistName", "NA");
             } 
             if (!Arrays.asList(elementNames).contains("trackName")) {
                 objectInArray.put("trackName", "NA");
             } 
             if (!Arrays.asList(elementNames).contains("currency")) {
                 objectInArray.put("currency", "USD");
             } 
             if (!Arrays.asList(elementNames).contains("previewUrl")) {
                 objectInArray.put("previewUrl", "https://audio-ssl.itunes.apple.com/apple-assets-us-std-000001/AudioPreview117/v4/37/fb/d2/37fbd23d-2cba-673b-9730-76d5dd9aa026/mzaf_9070472066879198917.plus.aac.p.m4a");
             } 
             if (!Arrays.asList(elementNames).contains("artworkUrl100")) {
                 objectInArray.put("artworkUrl100", "http://gamingonsteroids.com/uploads/profile/photo-thumb-746.png");
             }
             if (!Arrays.asList(elementNames).contains("releaseDate")) {
                 objectInArray.put("releaseDate", "NA");                 
             } 
             if (!Arrays.asList(elementNames).contains("trackTimeMillis")) {
                 objectInArray.put("trackTimeMillis", 1);                 
             }    
             // now get the updated elementNames from the JSON object
             elementNames = JSONObject.getNames(objectInArray);             
             // loop through the elementNames and extract specific information and store it in dataset JSON to display it in the app
             for (String elementName : elementNames) {                 
                 // only extract specific information
                 if (elementName.equals("artistName") | elementName.equals("trackName") | elementName.equals("currency") | elementName.equals("previewUrl") | elementName.equals("artworkUrl100") | elementName.equals("primaryGenreName") | elementName.equals("releaseDate") | elementName.equals("trackPrice") | elementName.equals("trackTimeMillis")) {
                    try {  
                        // if its releaseDate then get its value split it because it has both date and time
                        // only extract time and add it to temporary JSON addValue
                        if (elementName.equals("releaseDate")) {
                            valueString = objectInArray.getString("releaseDate");
                            String[] dateTime = valueString.split("T");
                            String date = dateTime[0]; 
                            addValue.put("releaseDate", date);
                            // if its not date then other key values could be extracted and added to addValue
                        } else {
                            valueString = objectInArray.getString(elementName);
                            addValue.put(elementName, valueString);
                        }
                         
                      // if its not a string then its only integer because the information I extract only contains either string or number and no boolean  
                    } catch (Exception e) {
                        try {
                            // if the key is trackTimeMillis, then extract the time in milliseconds, convert it to minutes.
                            // Then round it to two decimal places and store it in addValue
                            if (elementName.equals("trackTimeMillis")) {
                                valueDouble = objectInArray.getDouble("trackTimeMillis");
                                valueDouble = (valueDouble/1000)/60;
                                addValue.put("trackTimeMillis", Math.round(valueDouble*100.0)/100.0);                                
                              // if the key is trackPrice, then get the value and round it to two decimal places
                              // also add a discount price that my app offers with is random between 0% and 20%
                            } else if (elementName.equals("trackPrice")) {
                                valueDouble = objectInArray.getDouble(elementName);
                                addValue.put(elementName, Math.round(valueDouble*100.0)/100.0);
                                double discount = Math.random()*0.2;
                                addValue.put("discountPrice", Math.round((valueDouble-0.02)*(1-discount)*100.0)/100.0);
                            }
                          // if its not of the two formats then print out which element has the error and the exception  
                        } catch (Exception e1) {
                            System.out.println("element name is with exception is: " + objectInArray);
                            System.out.println("exception is: " + e1);
                        }
                    }                      
                 }                 
             }
             // add addValue JSON as the value of results key within dataset JSON
             dataset.append("results", addValue);                     
        }               
        return dataset;
    }
    

    /**
     * Make an HTTP request to a given URL
     * 
     * @param urlString The URL of the request
     * @return A string of the response from the HTTP GET.  This is identical
     * to what would be returned from using curl on the command line.
     */
    private String fetch(String urlString) {
        String response = "";
        try {
            URL url = new URL(urlString);
            /*
             * Create an HttpURLConnection.  This is useful for setting headers
             * and for getting the path of the resource that is returned (which 
             * may be different than the URL above if redirected).
             * HttpsURLConnection (with an "s") can be used if required by the site.
             */
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            // Read all the text returned by the server
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            String str;
            // Read each line of "in" until done, adding each to "response"
            while ((str = in.readLine()) != null) {
                // str is one line of text readLine() strips newline characters
                response += str;
            }
            in.close();
        } catch (IOException e) {
            System.out.println("Eeek, an exception");
            // Do something reasonable.  This is left for students to do.
        }        
        return response;
        
    }

    
}

