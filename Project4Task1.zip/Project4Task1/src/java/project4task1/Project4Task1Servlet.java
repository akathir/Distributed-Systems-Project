/* 
 * @author Annamalai Kathirkamanathan
 * Project 4 - Task 1 (Rest Server)
 * Last Modified: Nov 11, 2017
 *
 * The welcome-file in the deployment descriptor (web.xml) points
 * to this servlet. So this is the starting place for the web
 * application.
 *
 * The servlet is the controller of MVC.
 * The servlet get the request from app and then fetches info from the API using the model and then send back the spcific JSON info back to the app 
 * The model is provided by Project4Task1Model.
 */
package project4task1;
// Import libraries
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;


public class Project4Task1Servlet extends HttpServlet {

    Project4Task1Model itm = null;  // The "business model" for this app

    /**     
     * Arguments Initiate this servlet by instantiating the model that it will use.
    */
    @Override
    public void init() {
        itm = new Project4Task1Model();
    }
    
    /**     
     * Arguments This servlet will reply to HTTP GET requests via this doGet method
     * @param request get request from application
     * @param response send back the JSON
     * @throws javax.servlet.ServletException
     * @throws java.io.IOException
     * @throws java.io.UnsupportedEncodingException
    */
    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException, UnsupportedEncodingException {
               
        // To look at what the client accepts examine request.getHeader("Accept")
        // We are not using the accept header here.
        
        // Read what the client has placed in the GET data area
        String option = (request.getPathInfo()).substring(1);
        // Split the values in the request by comma and get the search and entity terms
        String[] nameEntity = option.split(",");
        String search = nameEntity[0];
        String entity = nameEntity[1];
        // Set the response to 200 - OK
        response.setStatus(200);
        // JSON object to send back the specific information back to the app
        JSONObject dataset = new JSONObject();
        // if either of the search or entity is not null and empty, then fetch info from the model and send it to the app
        if ((search != null & !"".equals(search)) | (entity != null & !"".equals(entity))) {
              try {                    
                    dataset = itm.doItunesSearch(search, entity);                    
                    PrintWriter out = response.getWriter();
                    // send JSON object to the client or app
                    out.println(dataset);                   
                // if exception then print out the log and error   
              } catch (Exception ex) {
                  Logger.getLogger(Project4Task1Servlet.class.getName()).log(Level.SEVERE, null, ex);
                  System.out.println("Exception is: " + ex);
              }                           
        }
        // Set what type of content is sent to client or app
        response.setContentType("application/json;charset=utf-8");
    }
}
