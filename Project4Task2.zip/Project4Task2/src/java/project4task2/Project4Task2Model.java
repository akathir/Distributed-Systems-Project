/*
 * @author Annamalai Kathirkamanathan
 * Project 4 - Task 2 (Model for the web application)
 * Last Modified: Nov 11, 2017
 * The model part of the web application helps in doing itunes search by requesting the Itunes API for the song, fetches the results
 * extracts only specific information that needs to be sent to the android application and sends back a JSON object back to sevlet.
 * It also does mongodb fetch for fetching the analytics and logs from information stored in mlab
 * Then sends the information back to the servlet which displays it in a dashboard view 
 */
package project4task2;
// Import libraries
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Arrays;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import org.json.JSONObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import org.bson.Document;
import org.json.JSONArray;

public class Project4Task2Model {
    
    /**     
     * Arguments.
     * @param searchTerm The term you are searching for.
     * @param mediaType The type of content which is always song in this case
     * @return dataset a JSON object containing only the specific information required by the android application
     * @throws java.io.UnsupportedEncodingException
     * @throws java.io.FileNotFoundException
    */
    public JSONObject doItunesSearch(String searchTerm, String mediaType) 
            throws UnsupportedEncodingException, FileNotFoundException  {
        /*
         * URL encode searchTerm and mediaType, e.g. to encode spaces as %20
         *
         * There is no reason that UTF-8 would be unsupported.  It is the
         * standard encoding today.  So if it is not supported, we have
         * big problems, so don't catch the exception.
         */
        searchTerm = URLEncoder.encode(searchTerm, "UTF-8");
        mediaType = URLEncoder.encode(mediaType, "UTF-8");
        // store string returned from fetch
        String response = "";

        // Create a URL for the API to request infomation 
        String itunesURL =
                "https://itunes.apple.com/search?term="
                + searchTerm
                +"&entity=" + mediaType;
                
        // Fetch the JSON data
        response = fetch(itunesURL);
        
        // Parse the Json string to get the Json object
        JSONObject dataset = new JSONObject();
        // valueDouble to store time and price information     
        double valueDouble = 0;
        // valueString to store all other information
        String valueString = "";
        // Convert the string format of JSON to JSON object
        JSONObject object = new JSONObject(response); 
        // get the results key value as json array 
        JSONArray jsonArray = object.getJSONArray("results");
        // get the length of the array to store it in the dataset json to send it to app        
        int totalCount = jsonArray.length();                
        dataset.put("resultCount", totalCount);     
        // loop through the results json array to extract specific information to be sent to app
        for (int i = 0, size = jsonArray.length(); i < size; i++) {
            // create a temporary JSON object to add value to dataset JSON during each iteration
             JSONObject addValue = new JSONObject();
             // get the JSON object for each json array and store the names of the keys in elementNames
             JSONObject objectInArray = jsonArray.getJSONObject(i);
             String[] elementNames = JSONObject.getNames(objectInArray);
             // if any one of the element name is not in elementNames then add a default value to each of them
             // in their objectInArray so that there is no error because the specific element is not present
             if (!Arrays.asList(elementNames).contains("trackPrice")) {
                 objectInArray.put("trackPrice", 0);
             } 
             if (!Arrays.asList(elementNames).contains("artistName")) {
                 objectInArray.put("artistName", "NA");
             } 
             if (!Arrays.asList(elementNames).contains("trackName")) {
                 objectInArray.put("trackName", "NA");
             } 
             if (!Arrays.asList(elementNames).contains("currency")) {
                 objectInArray.put("currency", "USD");
             } 
             if (!Arrays.asList(elementNames).contains("previewUrl")) {
                 objectInArray.put("previewUrl", "https://audio-ssl.itunes.apple.com/apple-assets-us-std-000001/AudioPreview117/v4/37/fb/d2/37fbd23d-2cba-673b-9730-76d5dd9aa026/mzaf_9070472066879198917.plus.aac.p.m4a");
             } 
             if (!Arrays.asList(elementNames).contains("artworkUrl100")) {
                 objectInArray.put("artworkUrl100", "http://gamingonsteroids.com/uploads/profile/photo-thumb-746.png");
             }
             if (!Arrays.asList(elementNames).contains("releaseDate")) {
                 objectInArray.put("releaseDate", "NA");                 
             } 
             if (!Arrays.asList(elementNames).contains("trackTimeMillis")) {
                 objectInArray.put("trackTimeMillis", 1);                 
             }    
             // now get the updated elementNames from the JSON object
             elementNames = JSONObject.getNames(objectInArray);             
             // loop through the elementNames and extract specific information and store it in dataset JSON to display it in the app
             for (String elementName : elementNames) {                 
                 // only extract specific information
                 if (elementName.equals("artistName") | elementName.equals("trackName") | elementName.equals("currency") | elementName.equals("previewUrl") | elementName.equals("artworkUrl100") | elementName.equals("primaryGenreName") | elementName.equals("releaseDate") | elementName.equals("trackPrice") | elementName.equals("trackTimeMillis")) {
                    try {  
                        // if its releaseDate then get its value split it because it has both date and time
                        // only extract time and add it to temporary JSON addValue
                        if (elementName.equals("releaseDate")) {
                            valueString = objectInArray.getString("releaseDate");
                            String[] dateTime = valueString.split("T");
                            String date = dateTime[0]; 
                            addValue.put("releaseDate", date);
                            // if its not date then other key values could be extracted and added to addValue
                        } else {
                            valueString = objectInArray.getString(elementName);
                            addValue.put(elementName, valueString);
                        }
                         
                      // if its not a string then its only integer because the information I extract only contains either string or number and no boolean  
                    } catch (Exception e) {
                        try {
                            // if the key is trackTimeMillis, then extract the time in milliseconds, convert it to minutes.
                            // Then round it to two decimal places and store it in addValue
                            if (elementName.equals("trackTimeMillis")) {
                                valueDouble = objectInArray.getDouble("trackTimeMillis");
                                valueDouble = (valueDouble/1000)/60;
                                addValue.put("trackTimeMillis", Math.round(valueDouble*100.0)/100.0);                                
                              // if the key is trackPrice, then get the value and round it to two decimal places
                              // also add a discount price that my app offers with is random between 0% and 20%
                            } else if (elementName.equals("trackPrice")) {
                                valueDouble = objectInArray.getDouble(elementName);
                                addValue.put(elementName, Math.round(valueDouble*100.0)/100.0);
                                double discount = Math.random()*0.2;
                                addValue.put("discountPrice", Math.round((valueDouble-0.02)*(1-discount)*100.0)/100.0);
                            }
                          // if its not of the two formats then print out which element has the error and the exception  
                        } catch (Exception e1) {
                            System.out.println("element name is with exception is: " + objectInArray);
                            System.out.println("exception is: " + e1);
                        }
                    }                      
                 }                 
             }
             // add addValue JSON as the value of results key within dataset JSON
             dataset.append("results", addValue);                     
        }        
        return dataset;
    }
    

    /**
     * Make an HTTP request to a given URL
     * 
     * @param urlString The URL of the request
     * @return A string of the response from the HTTP GET.  This is identical
     * to what would be returned from using curl on the command line.
     */
    private String fetch(String urlString) {
        String response = "";
        try {
            URL url = new URL(urlString);
            /*
             * Create an HttpURLConnection.  This is useful for setting headers
             * and for getting the path of the resource that is returned (which 
             * may be different than the URL above if redirected).
             * HttpsURLConnection (with an "s") can be used if required by the site.
             */
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            // Read all the text returned by the server
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            String str;
            // Read each line of "in" until done, adding each to "response"
            while ((str = in.readLine()) != null) {
                // str is one line of text readLine() strips newline characters
                response += str;
            }
            in.close();
        } catch (IOException e) {
            System.out.println("Eeek, an exception");
            // Do something reasonable.  This is left for students to do.
        }        
        return response;
        
    }
    
    /**
     * Make an HTTP request to the mongodb stored in mlab and returns the 
     * log information which is used to both show the logs and few analytics
     * in the dashboard
     * @return fetchResults A array list of the analytics and the logs
     */    
    
    public ArrayList doMongodbFetch () {
        // fetchResults to store the final results which is sent back to servlet
        ArrayList<String> fetchResults  = new ArrayList();
        // totalCount to store all counts to show average result count
        ArrayList<Integer> totalCount = new ArrayList();
        // timeTakenSec to store time taken to show average time taken
        ArrayList<Double> timeTakenSec = new ArrayList();
        // all search values sorted
        ArrayList<Object> sortedSearch = new ArrayList();
        // difference between actual and discount price
        ArrayList<Double> priceDiff = new ArrayList();
        // hash map to sort the search 
        HashMap<String,Integer> searchCount = new HashMap<>();
        // log values to store all the logs 
        StringBuilder logValues = new StringBuilder();
       
        String username = "database";
        String password = "database"; 
        // Source - http://mongodb.github.io/casbah/2.8/reference/connecting/
        // connect to mongobd using URL with username and password
        MongoClientURI uri  = new MongoClientURI("mongodb://"+username+":"+password+"@ds251245.mlab.com:51245/project4database");             
        //create a client to get the database from the uri
        MongoClient client = new MongoClient(uri);  
        MongoDatabase db = client.getDatabase(uri.getDatabase());
        // get the collection name from the database
        MongoCollection collection = db.getCollection("database");
        // iterate through the documents of the collection
        MongoCursor<Document> cursor = collection.find().iterator();            
        try {
            // until the cursor has documents ietrate through and get all infomation
            while (cursor.hasNext()) {   
                // convert document to json string
                String report = cursor.next().toJson();
                // convert string to JSON object
                JSONObject object = new JSONObject(report);
                // add values to logValues to show the log results in dashboard
                logValues.append("<tr><td>").append(object.get("userAgent")).append("</td><td>").append(object.get("searchURL")).append("</td><td>").append(object.get("search")).append("</td><td>").append(object.get("entity")).append("</td><td>").append(object.get("startTime")).append("</td><td>").append(object.get("endTime")).append("</td><td>").append(object.get("timeDiff")).append("</td><td>").append(object.get("count")).append("</td><td>").append(object.get("jsonData")).append("</td></tr>");                    
                // get the JSON object for the jsonData key
                JSONObject object1 = object.getJSONObject("jsonData");
                // if the value of jsonData contains results then get the values of the
                // results key as JSON array to iterate through them to get the required analytics
                if(object1.keySet().contains("results")) {
                    JSONArray jsonArray = object1.getJSONArray("results");
                    // iterate through the results of JSON array
                    for (int i = 0, size = jsonArray.length(); i < size; i++) {
                        // trackPrice and discountPrice to store the price values
                        // to claculate average discount per song
                        double trackPrice = 0;
                        double discountPrice = 0;                
                        // get each of the JSON objects
                        JSONObject objectInArray = jsonArray.getJSONObject(i);
                        // get the element name for the JSON object
                        String[] elementNames = JSONObject.getNames(objectInArray);
                        // iterate through the element names and get specific information
                        // to calculate analytics and display it in the dashboard
                        for (String elementName : elementNames) {
                            // name is trackprice then see if its less than or greater than 0
                            // if less than zero set it to zero
                            // else add to trackPrice variable
                            if (elementName.equals("trackPrice")) {
                                if(objectInArray.getDouble("trackPrice") <= 0) {
                                    trackPrice = 0;
                                } else {
                                    trackPrice = objectInArray.getDouble("trackPrice");
                                }                                                                        
                            }
                            // same for the discount price if its less than zero set to zero 
                            // else add it to discountPrice variable
                            if (elementName.equals("discountPrice")) {
                                if (objectInArray.getDouble("discountPrice") <= 0) {
                                    discountPrice = 0;
                                } else {
                                   discountPrice = objectInArray.getDouble("discountPrice"); 
                                }                                                                        
                            }                                
                        }
                        // calculate the disocunt price the for each of the song and add it to priceDiff array
                        priceDiff.add(Math.round((trackPrice-discountPrice)*100.00)/100.00);
                    }                        
                }
                // get the search terms from the JSON and add it to searchCount array
                String search = object.getString("search");
                if(searchCount.containsKey(search)) {
                    searchCount.put(search,searchCount.get(search)+1);
                } else {
                    searchCount.put(search,1);
                } 
                // add the count to total count array
                totalCount.add(object.getInt("count"));
                // add time diff to time taken array
                timeTakenSec.add(object.getDouble("timeDiff"));
            }
        } finally {
            // close the cursor
            cursor.close();
        }
        // find the average of total count, time taken, price difference
        double sum = 0;
        // find the total sum of count
        for(int i=0; i<totalCount.size();i++) {
            sum += totalCount.get(i);
        }
        // find the average of the total count sum
        double avgCount = Math.round((sum/totalCount.size())*100.00)/100.00;

        double sumTime = 0;
        for(int i=0; i<timeTakenSec.size();i++) {
            sumTime += timeTakenSec.get(i);
        }            
        double avgTime = Math.round((sumTime/timeTakenSec.size())*100.00)/100.00;  

        double sumPriceDiff = 0;
        for(int i=0; i<priceDiff.size();i++) {
            sumPriceDiff += priceDiff.get(i);
        }            
        double avgPriceDiff = Math.round((sumPriceDiff/priceDiff.size())*1000.00)/1000.00;              
        // sort the search values by comparing the count of searches using collections sort's
        // comparator using the count of each search
        List<Entry<String, Integer>> searchValueSort = new LinkedList<>(searchCount.entrySet());                                 
        Collections.sort(searchValueSort, new Comparator<Entry<String, Integer>>() {
            @Override
            public int compare(Entry<String, Integer> first, Entry<String, Integer> second) {
                return second.getValue().compareTo(first.getValue());                   
            }
        });
        // add the sorted value to the sortedSearch array list
        for (Entry<String, Integer> item: searchValueSort) {
            sortedSearch.add(item.getKey());
        }  
    // add the average values, sorted search list and logs to fetchResults to be sent to servlet
    // to display the dashboard
    fetchResults.add(String.valueOf(avgCount));
    fetchResults.add(String.valueOf(avgTime));
    fetchResults.add(String.valueOf(avgPriceDiff));
    fetchResults.add(sortedSearch.toString());
    fetchResults.add(logValues.toString());
   
    return fetchResults;        
   }   
}

