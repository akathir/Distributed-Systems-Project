/* 
 * @author Annamalai Kathirkamanathan
 * Project 4 - Task 1 (Rest Server)
 * Last Modified: Nov 11, 2017
 *
 * The welcome-file in the deployment descriptor (web.xml) points
 * to this servlet.  So it is the starting place for the web
 * application.
 *
 * The servlet is the controller of MVC
 * The servlet get the request from app and then fetches info from the API using the model and then send back the spcific JSON info back to the app
 * If the user requests /getDashboard then it fetches the documents from mongodb collection and displays analytics and logs
 * /getDashboard directs to dashboard jsp which displays the analytics and logs in table format on a browser
 * The model is provided by Project4Task1Model.
 */
package project4task2;
// Import libraries
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoCollection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import org.bson.Document;


public class Project4Task2Servlet extends HttpServlet {

    Project4Task2Model itm = null;  // The "business model" for this app

    /**     
     * Arguments Initiate this servlet by instantiating the model that it will use.
    */
    @Override
    public void init() {
        itm = new Project4Task2Model();
    }

    /**     
     * Arguments This servlet will reply to HTTP GET requests via this doGet method
     * @param request get request from application
     * @param response send back the JSON
     * @throws javax.servlet.ServletException
     * @throws java.io.IOException
     * @throws java.io.UnsupportedEncodingException
    */
    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException, UnsupportedEncodingException {
        
        // if the request has getResults URL then it calls the API and fetched JSON results
        // sends it to the app
        if (request.getServletPath().equals("/getResults")) {
            // start time and end time to store the info in mongodb
            long startTime = 0;
            long endTime = 0;        

            // Read what the client has placed in the GET data area
            String option = (request.getPathInfo()).substring(1);
            // Split the values in the request by comma and get the search and entity terms 
            String[] nameEntity = option.split(",");
            String search = nameEntity[0];
            String entity = nameEntity[1];
            // get the itunes URL to log in mongodb
            String itunesURL =
                    "https://itunes.apple.com/search?term="
                    + search
                    +"&entity=" + entity;            
            // Set the response to 200 - OK          
            response.setStatus(200);
            // JSON object to send back the specific information back to the app
            JSONObject dataset = new JSONObject();
            // determine what type of device our user is to log the information
            String ua = request.getHeader("User-Agent");
            // if either of the search or entity is not null and empty, then fetch info from the model and send it to the app
             if ((search != null & !"".equals(search)) | (entity != null & !"".equals(entity))) {
                  try {   
                        // find the current time to log info
                        startTime = System.currentTimeMillis();
                        // get back the JSON data from API
                        dataset = itm.doItunesSearch(search, entity);                     
                        // find current time to log info
                        endTime = System.currentTimeMillis();                    
                        // find the differece in time to log info
                        double timeDiff = Math.round((endTime-startTime)*0.001*100.00)/100.00;                    
                        // total count of results for each request to log info
                        int totalCount = dataset.getInt("resultCount");   
                        // convert the time to specific format
                        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss.SSS");
                        // conver the start and end date to the specific format
                        Date startTimeFormat = new Date(startTime);                        
                        Date endTimeFormat = new Date(endTime);
                        // send the info to dopost which does HTTP POST request to mongodb
                        doPost(ua, itunesURL, search, entity, totalCount, timeFormat.format(startTimeFormat), timeFormat.format(endTimeFormat), timeDiff, dataset);
                        PrintWriter out = response.getWriter();
                        // send JSON object to the client or app
                        out.println(dataset);                   
                    // handle errors
                  } catch (Exception ex) {
                      Logger.getLogger(Project4Task2Servlet.class.getName()).log(Level.SEVERE, null, ex);
                      System.out.println("Exception is: "+ ex);
                  }             
            }
            // Set what type of content is sent to client or app
            response.setContentType("application/json;charset=utf-8");                        
        }
        // if the request has /getDashboard URL then get log information from mongodb
        // and pass it to dashboard jsp to view the information in browser
        if (request.getServletPath().equals("/getDashboard")) {
            // result array list to get info 
            ArrayList<String> results  = new ArrayList();
            // get results
            results = itm.doMongodbFetch();
            // store info to specific variables to display it in jsp
            String avgCount = results.get(0);
            String avgTime = results.get(1);
            String avgPriceDiff = results.get(2);
            String sortedSearch = results.get(3);
            String logValues = results.get(4);
            // set the request attributes to display it in dashboard
            request.setAttribute("avgTotalCount",avgCount);
            request.setAttribute("avgTimeSec",avgTime);
            request.setAttribute("avgPriceDiff",avgPriceDiff);
            request.setAttribute("sortedSearch",sortedSearch);
            request.setAttribute("logValues",logValues);
            // Transfer control over the dashboard "view"
            RequestDispatcher view = request.getRequestDispatcher("dashboard.jsp");
            view.forward(request, response);
            
        }
        
    }
    
    /**     
     * Arguments This will do a HTTP POST requests via this doPost method
     * @param ua the user agent to be logged
     * @param searchURL the search URL 
     * @param search the search term
     * @param entity the type of search. In our case is "song"
     * @param totalCount the total count of results for each search term
     * @param startTime the request or start time of the search
     * @param endTime the response time or end time of getting back JSON
     * @param timeDiff the time difference between start and end
     * @param jsonData the JSON data sent to the app
    */    
    protected void doPost (String ua, String searchURL, String search, String entity, int totalCount, String startTime, String endTime,double timeDiff, Object jsonData) {
        String username = "database";
        String password = "database"; 
        // Source - http://mongodb.github.io/casbah/2.8/reference/connecting/
        // connect to mongobd using URL with username and password
        MongoClientURI uri  = new MongoClientURI("mongodb://"+username+":"+password+"@ds251245.mlab.com:51245/project4database"); 
        //create a client to get the database from the uri
        MongoClient client = new MongoClient(uri);        
        MongoDatabase db = client.getDatabase(uri.getDatabase());        
        // get the collection name from the database
        MongoCollection collection = db.getCollection("database");
        // add the values to a temporary JSON object which is then added to the collection document 
        JSONObject dataDatabase = new JSONObject();
        dataDatabase.put("userAgent", ua);
        dataDatabase.put("searchURL", searchURL);
        dataDatabase.put("search", search);
        dataDatabase.put("entity", entity);
        dataDatabase.put("count", totalCount);
        dataDatabase.put("startTime", startTime);
        dataDatabase.put("endTime", endTime);
        dataDatabase.put("timeDiff", timeDiff);
        dataDatabase.put("jsonData", jsonData);
        try {
            // add documents to collection
            collection.insertOne(new Document(Document.parse(dataDatabase.toString())));
          // handle errors  
        } catch (Exception e) {
            System.out.println("Did not insert data. Error is: " + e);
        }
        
        
    }

}
